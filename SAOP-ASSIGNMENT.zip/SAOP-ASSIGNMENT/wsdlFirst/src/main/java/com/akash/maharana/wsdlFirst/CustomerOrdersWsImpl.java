package com.akash.maharana.wsdlFirst;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cxf.feature.Features;

import com.maharana.akash.trainings.CreateOrdersRequest;
import com.maharana.akash.trainings.CreateOrdersResponse;
import com.maharana.akash.trainings.CustomerOrdersPortType;
import com.maharana.akash.trainings.GetOrdersRequest;
import com.maharana.akash.trainings.GetOrdersResponse;
import com.maharana.akash.trainings.Order;
import com.maharana.akash.trainings.Product;

@Features(features="org.apache.cxf.feature.LoggingFeature")
public class CustomerOrdersWsImpl implements CustomerOrdersPortType{
	
	Map<BigInteger,List<Order>> customerOrders=new HashMap<>();
	int currentId;
	
	public CustomerOrdersWsImpl() {
		init();
	}
	
	private void init() {
		List<Order> orders=new ArrayList<>();
		Order order=new Order();
		order.setId(BigInteger.valueOf(1));
		
		Product product=new Product();
		product.setDescription("IPhone");
		product.setId("1");
		product.setQuantity(BigInteger.valueOf(3));
		order.getProduct().add(product);
		orders.add(order);
		customerOrders.put(BigInteger.valueOf(++currentId), orders);
	}

	@Override
	public GetOrdersResponse getOrders(GetOrdersRequest request) {
		BigInteger customerId=request.getCustomerId();
		List<Order> orders=customerOrders.get(customerId);
		GetOrdersResponse response=new GetOrdersResponse();
		response.getOrder().addAll(orders);
		return response;
	}

	@Override
	public CreateOrdersResponse createOrders(CreateOrdersRequest request) {
		BigInteger customerId=request.getCustomerId();
		Order order=request.getOrder();
		List<Order> orders=customerOrders.get(customerId);
		orders.add(order);
		CreateOrdersResponse response=new CreateOrdersResponse();
		response.setResult(true);
		return response;
	}
	@Override
	public DeleteOrdersResponse deleteOrders(DeleteOrdersRequest request) {
		BigInteger customerId=request.getCustomerId();
		Order customer_order=request.getOrder();
		List<Order> order_list=customerOrders.get(customerId);
		order_list.remove(customer_order);
		DeleteOrdersResponse res=new DeleteOrdersResponse();
		res.setResult(true);
 		return res;
	}
	
	@Override
	public UpdateOrdersResponse updateOrders(UpdateOrdersRequest request) {
		BigInteger customerId=request.getCustomerId();
		Order customer_order=request.getOrder();
		List<Order> orders_list=customerOrders.get(customerId);
		for(Order ord : orders_list) {
			if(ord.getId() == request.getOrder().getId()) {
				ord = request.getOrder();
				break;}
		}
		UpdateOrdersResponse res=new UpdateOrdersResponse();
		res.setResult(true);
		return res;}
}
