package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

public class Main {
	 List<Employee> emp_list = new ArrayList<Employee>();
	 
	 public Main() {
		 emp_list.add(new Employee(101,"manish"));
		 emp_list.add(new Employee(102,"Hemanth"));
		 emp_list.add(new Employee(103,"Rafath"));
		 emp_list.add(new Employee(104,"impana"));
		 emp_list.add(new Employee(105,"kirthi"));
	 }
	 
	@GET
	@Produces("application/json")
	public List<Employee> getAllUsers() {
		return emp_list;
	}
	
	
	@POST
	@Path("/post")
	@Produces("application/json")
	@Consumes("application/json")
	public String[] fun(Employee emp ) {
		emp_list.add(emp);
		return new String[] {"Sucessfully inserted"};
			
	}
	
	
	@DELETE
	@Path("/del")
	@Produces("application/json")
	@Consumes("application/json")
	public String[] del(int id ) {
	  for(Employee e:emp_list) {
		  if(e.getEmp_id()==id)
		  {
			  emp_list.remove(e);
			  return new String[] {"successfuly removed"};
		  }
	  }
	  return new String[] {"details not found"};
	  
	
	
	}
}
