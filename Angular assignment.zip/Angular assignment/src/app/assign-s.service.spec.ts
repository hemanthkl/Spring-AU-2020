import { TestBed } from '@angular/core/testing';

import { AssignSService } from './assign-s.service';

describe('AssignSService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AssignSService = TestBed.get(AssignSService);
    expect(service).toBeTruthy();
  });
});
