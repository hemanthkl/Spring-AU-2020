import { Component,OnInit } from '@angular/core';
import { AssignSService } from './assign-s.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'assign';
  arr=[];
  constructor(public service:AssignSService){}
 
  ngOnInit(){
    console.log(this.arr);
    this.arr=this.service.get();
    
  }

}
