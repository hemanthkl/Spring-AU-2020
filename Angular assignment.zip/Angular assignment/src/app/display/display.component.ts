import { Component, OnInit } from '@angular/core';
import { AssignSService } from '../assign-s.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
  constructor(public Myser:AssignSService) { }
   arr=[];
  ngOnInit() {
    this.arr=this.Myser.get();
  }

}
