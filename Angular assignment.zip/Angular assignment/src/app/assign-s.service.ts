import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AssignSService {
  id=0;
  array=[];
  get()
  {
    return this.array;
  }
  set(value)
  {
    this.id+=1;
    this.array.push({id:this.id,mail:value.mail,password:value.password,cpassword:value.cpassword})
    

  }
  constructor() { }
}
