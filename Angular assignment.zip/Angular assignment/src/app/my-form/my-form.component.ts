import { Component, OnInit } from '@angular/core';
import{FormGroup,FormControl} from '@angular/forms'
import { AssignSService } from '../assign-s.service';

@Component({
  selector: 'app-my-form',
  templateUrl: './my-form.component.html',
  styleUrls: ['./my-form.component.css']
})
export class MyFormComponent implements OnInit {
constructor(public AssignSService:AssignSService){}
myform = new FormGroup({
  mail : new FormControl(''),
  password: new FormControl(''),
  cpassword : new FormControl('')

});
emp_mail="";
emp_password="";
emp_cpassword="";


onclick(){
  //console.log(this.myform.value);
  this.emp_mail="";
  this.emp_cpassword="";
  this.emp_password="";

  if(this.myform.value.mail == '')
  {
    this.emp_mail="**This field cannot be empty";
  }
  if(this.myform.value.password == '')
  {
    this.emp_password="**This field cannot be empty";
  }
  if(this.myform.value.cpassword == '')
  {
    this.emp_cpassword="**This field cannot be empty";
  }
  if(this.myform.value.mail!='' && this.myform.value.password!='' && this.myform.value.cpassword!=''){
    this.AssignSService.set(this.myform.value);
    this.myform.reset();
  }
    
  this.myform.value.reset();
  
  
}
ngOnInit(){}
}

